import React, { Component } from 'react'

export default class All extends Component {
    render() {
        return (
            <div>
                all
            </div>
        )
    }
}
