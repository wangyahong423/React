import React, { Component } from 'react'

export default class Api extends Component {
    render() {
        return (
            <div>
                api
            </div>
        )
    }
}
