import React, { Component } from 'react'

export default class Job extends Component {
    render() {
        return (
            <div>
                job
            </div>
        )
    }
}
