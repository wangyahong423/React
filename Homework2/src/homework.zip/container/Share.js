import React, { Component } from 'react'

export default class Share extends Component {
    render() {
        return (
            <div>
                share
            </div>
        )
    }
}
