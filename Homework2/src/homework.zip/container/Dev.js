import React, { Component } from 'react'

export default class Dev extends Component {
    render() {
        return (
            <div>
                dev
            </div>
        )
    }
}
