import React, { Component } from 'react';
import {Link,Route} from 'react-router-dom';
import All from './All';
import Jinghua from './Jinghua';
import Share from './Share';
import Ask from './Ask';
import Job from './Job';
import Dev from './Dev';

export default class Home extends Component {
    render() {
        let {url} = this.props.match;//获取资源路径的url参数
        console.log(this.props.match);
        return (
            <div className='panel'> 
                <div className='header'>
                    <a className='topic-tab current-tab'><Link to={`${url}/all`}>全部</Link></a>
                    <a className='topic-tab '><Link to={`${url}/jinghua`}>精华</Link></a>
                    <a className='topic-tab '><Link to={`${url}/share`}>分享</Link></a>
                    <a className='topic-tab '><Link to={`${url}/ask`}>问答</Link></a>
                    <a className='topic-tab '><Link to={`${url}/job`}>招聘</Link></a>
                    <a className='topic-tab '><Link to={`${url}/dev`}>客户端测试</Link></a>
                </div>
                <div>
                    <Route path={url+'/all'} component={All} />
                    <Route path='/home/jinghua' component={Jinghua} />
                    <Route path='/home/share' component={Share} />
                    <Route path='/home/ask' component={Ask} />
                    <Route path='/home/job' component={Job} />
                    <Route path='/home/dev' component={Dev} />
                </div>
            </div>
        )
    }
}
