import React, { Component } from 'react'

export default class Jinghua extends Component {
    render() {
        return (
            <div>
                jinghua
            </div>
        )
    }
}
