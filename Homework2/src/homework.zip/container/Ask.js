import React, { Component } from 'react'

export default class Ask extends Component {
    render() {
        return (
            <div>
                ask
            </div>
        )
    }
}
